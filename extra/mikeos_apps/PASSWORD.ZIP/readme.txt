First copy AUTORUN.BAS and NEWPASS.BAS to your MikeOS disk
and boot the disk on an emulator or a real machine.
Next run NEWPASS.BAS and enter a password when prompted.
A new (lightly) encripted password will be created.
When you reboot it will prompt for the password before loading.
If you want to change your password then simply run 
NEWPASS.BAS again, enjoy!

