Multiscreen Library
Mail: mikeosdeveloper@gmail.com for question, comments or bugs
Released under the GNU General Public Licence v3

To use these functions add the file 'scrlib.bas' to you MikeOS
disk and add following line to the start of your program:
INCLUDE "SCRLIB.BAS"

You can see a sample in the file 'screen.bas'.
Uses throw away varibles V-Z

Name: initscr
Description: Prepare the library and open a blank screen.
Input: (none)
Output: (none)
Notes: Will destroy screen 1 contents, use before other functions.

Name: closescr
Description: saves the current screen and returns to the original display
Input: (none)
Output: (none)
Notes: Use this before finishing your program.

Name: writescr
Description: writes a string with escape functions to the screen
Input: $1 = string to print, $2 = text output escape string
Output: $2 = inputted string
Notes: 
writescr the '@' symbol for escape codes ('v' is a hexdecimal digit)
  @@ = Actually print the '@' symbol
  @N = Start a new line
  @Cv = Set the text colour
  @Hv = Set the background colour
  @W = Set the text colour to white
  @I = Change the text colour to it's intense version
  @D = Change the text colour to it's dim version
  @K = Wait for a key before continuing
  @B = Produce a beep from the PC Speaker
  @Sv = Print a number of spaces
  @P = Print string $2
  @G = Input string $2
  
Name: getscr
Description: get the number of the current screen
Input: (none)
Output: x = screen number
Notes:

Name: setscr
Description: switch to a different screen
Input: v = screen number
Output: (none) 
Notes: may take some time


