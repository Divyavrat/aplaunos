msxpic v1.6c
------------
msxpic is a MSX 2 SCREEN 8 BSAVE picture viewer for DOS. It comes with the
source code and six sample pictures. The scope of this project was to explore
programming for VGA mode-X. You'll need Borland Turbo Assembler (tested with
TASM 3.2). To build, use make.bat file. To view sample MSX pictures, use
show.bat. Source code may be buggy and suboptimal, it is my first program
completely written in x86 assembler. It will probably be the last as well,
since I now have access to Watcom C/C++ 10.0 compiler.

Thanks
------
Andrei Veltchev for explaining the basics of VGA mode-X.
John Bridges for his excellent VGAKIT v4.1.

Greetings
---------
Vitali Miagkov, Eugen Condur and all my friends.

Adrian Oboroc, January 16, 1996
