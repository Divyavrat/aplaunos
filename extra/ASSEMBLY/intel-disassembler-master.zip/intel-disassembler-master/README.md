x86 disassembler for DOS
========================

Written in x86 assembly (TASM, DOS).

Sources
-------
* [This table](http://ref.x86asm.net/coder32.html) was used as a reference for the opcode table.

License
-------

MIT (see LICENSE)
