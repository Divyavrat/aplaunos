#!/bin/bash

nasm -f bin tetris.asm -o tetris.com
nasm -f bin sokoban.asm -o sokoban.com
nasm -f bin snake.asm -o snake.com
