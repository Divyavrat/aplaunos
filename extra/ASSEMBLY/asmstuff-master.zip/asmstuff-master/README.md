asmstuff
========

Some random stuff in assembler (under DOS) I wrote before I entered university. For Netwide Assembler.

Slightly cleaned up (updated character sets, whitespace fixes).

Functions which are used in the sources but reverse-engineered from Turbo Pascal 7.00 from Borland, so not available here:
Delay
InitDelay
NoSound
Randomize
RandWord
Sound
