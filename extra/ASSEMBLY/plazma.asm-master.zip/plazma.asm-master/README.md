plazma.asm
==========

A 256 byte intro for DOS written in Assembly x86

![](screenshot.png)
