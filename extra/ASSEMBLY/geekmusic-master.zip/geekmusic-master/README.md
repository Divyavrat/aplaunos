## A DOS program teaching you how to play an 8-key electronic organ


The game looks like below:

![screenshot](https://github.com/onesuper/geekmusic/raw/master/screenshot.jpg)


The key is dropping down along the socket and
you press the keyboards 1 to 8 when the key meets the bottom 
of the socket.


This program is written in ancient DOS assembly languange
and is tested in DOSBOX.


The default music is Happy Birthday to You. And you can replace it with Happy Song~ 
