ppony
=====

A small DOS program that displays a 16 colour pixel array on screen. Accompanied with a simplistic 16colour 4bpp bmp to bin converter.

Making PBINGEN write 4bpp BMP in reverse order to halt the need of turning images upside down before conversion is planned.
There's also hope to making it write correct colour, rather than hoping the indexed colours are correspdoding in the bmp to the VGA numbers.
