asmap
=====

A DOS application that displays a bitmap image... almost
