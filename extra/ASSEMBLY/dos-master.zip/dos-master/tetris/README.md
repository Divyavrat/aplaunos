
Tetris v1.0
==============================================================================
Joe Wingbermuehle
1998-12-26
http://joewing.net

Requirements
------------------------------------------------------------------------------
Just about any x86 system with DOS.

Description
------------------------------------------------------------------------------
This is the classic game of Tetris. The object is to make the blocks
disappear by getting rows of solid blocks.

Keys
------------------------------------------------------------------------------
Use the right/left/down arrow keys to move.
Press the space bar to rotate the block.
Press [Esc] to exit the game.

