
DStar v0.3
==============================================================================
Joe Wingbermuehle
1998-04-24
http://joewing.net

Requirements
------------------------------------------------------------------------------
Pretty much any x86 system with DOS.

Description
------------------------------------------------------------------------------
This is a game in which the object is to get the yellow dots. You are the
white cross and you try to run over the dots. You can swap places with the
box to get the dots since every move sends you flying all the way to the
next wall!

