dos-game-suite-8086
===================

Some fumbling around with x86_16 mode 13h graphics using DOS.

